<?php

$txt = lire('relayDNS.py');
$lines = explode("\n", $txt);
$res = '';
foreach($lines as $line){
	if($res != '') $res .= "#13#10+\n";
  $line = str_replace("'", "''", $line);
  $line = str_replace("\r", "", $line);
	$res .= "    '".$line."'";
}
echo '<textarea style="width:100%;height:790px">  script := '.$res.';</textarea>';



function lire($fichier){
    $fp = fopen($fichier, "rb");
    $txt = fread($fp, filesize ($fichier));
    fclose($fp);
    return $txt;
}
function ecrire($fichier, $txt){
    $fp = fopen($fichier,"w+");                 
    fputs($fp, $txt);            
    fclose($fp);
}
